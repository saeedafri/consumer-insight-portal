# Handoff — Forsta ETL, Schema and UI (7 Oct 2026)

Plan: `docs/superpowers/plans/2026-10-07-forsta-etl-build.md`
Spec: `docs/superpowers/specs/2026-10-07-cip-forsta-etl-and-ui-design.md`
Earlier ledgers: `.superpowers/sdd/2026-10-01-forsta-api-phase7/`, `.superpowers/sdd/2026-10-01-surveymonkey-phase6/`

## Standing rules (from the user, still in force)
- Never commit or push. Never add authorship or attribution anywhere.
- Forsta: GET only. Never reactivate, edit or delete a survey; never change view-only status.
- API key lives in `.env` (FORSTA key, host se1.decipherinc.com, header `x-apikey`). Never print it.
- Never edit any Excel file. Do not touch market-data-stg or the MIP Streamlit processes on 8501/8503.
- Hibernated (428) waves: leave alone. No Azure Blob archive for now. Excel route retired.
- "Please continue. Do not ask or disturb me again." Follow the best recommendation; no questions.
- TDD (RED→GREEN), opus review at the end of the phase, keep this ledger current.

## Decisions taken
1. Rename `csi_` → `cip_`: done (code + dwh_stg + local SQLite `data/csi_local.db`).
   Not renamed on purpose: cookie keys `csi_auth`, `csi_session`, `csi_cookies`, `csi_auth_next`;
   the `csi_db` test fixture; the `csi_local.db` file name; CSS class `csi-footer`.
2. Excel route retired: `etl/excel_parsers.py` → `etl/records.py` (NO_TO, clean_text, ParsedQuestion
   with `flags` and `bipolar`, normalise_label_cell). Crosstabs page, ingest_excel, crosstab ingestion,
   repository.crosstab/banners and the Excel-dependent tests are gone.
3. Partitioning deferred until >100 M answer rows (InnoDB forbids FKs on partitioned tables).

## Task status
| # | Task | Status |
|---|------|--------|
| 1 | Rename | ✅ verified on dwh_stg: 29 cip_ tables, 9 v_cip_ views, 0 csi_ left, 11,771,927 answers, 160 waves |
| 2 | Retire Excel | ✅ suite was 180 passed afterwards |
| 3 | Schema (code) | ✅ in `sql/001_schema.sql` + `app/core/schema_upgrade.py`; **not yet applied to dwh_stg** |
| 4 | API adapter | ✅ `etl/forsta_api.py`, `etl/loaders.py`; adapter tests pass |
| 5 | Pipeline `etl/forsta_etl.py` | ✅ SUBSTR/Python body fix; weekly runner on forsta_etl; ingest_api, to_record, survey_path client methods + POST datafeed_ack retired; 187 passed |
| 6 | Backfill on dwh_stg | 🔶 schema applied (31 tables); discover: 31 due / 51 hibernated / 8 testing; 260907 loaded (sid 235, 537 resp); `--due` running |
| 7 | UI (search + auto-charted report) | ✅ `2_Survey_Report.py` (replaces Question explorer, url /report): search over cip_search (FULLTEXT, stopwords skipped; LIKE fallback), every question charted by shape (chart_kind), butterfly + distribution added, Plotly transitions; perf P95 search 0.26 s, whole wave 1.05 s; browser-checked on dwh_stg (port 8611) |
| 8 | Review, docs, memory | 🔶 opus review: 11 findings, 9 fixed TDD (hibernated reconcile, MySQL string/number limits, dropped respondents, status restore on failed reload, register reopen + --survey failure, PII denylist, 4-dp reconcile, wave reuse per path, $ escaping, butterfly by item, 429/5xx retry); left: max_retries hard-coded 4, survey list fetched per wave. Docs: README, docs/03, docs/06, spec status updated. 212 passed |

## Next step (exactly where it stopped)
`.venv/bin/python -m pytest -q tests/test_forsta_etl.py` fails:
```
sqlite3.OperationalError: no such function: LEFT
INSERT INTO cip_search (...) SELECT 'question', ..., LEFT(q.qtext, 500), q.qcode ...
```
Fix `index_survey()` in `etl/forsta_etl.py`: `LEFT(x, 500)` → `SUBSTR(x, 1, 500)` (works on MySQL and SQLite);
build the survey row's body in Python instead of `CONCAT`. Rerun that file, then the full suite.

Then, in order:
1. `scripts/weekly_forsta.py` → use `forsta_etl` (discover + run_due + drift); retire `run_pipeline.ingest_api`.
2. Apply schema on dwh_stg: `python scripts/init_db.py` (new tables cip_forsta_survey, cip_search; new columns;
   index ix_survey_pick; drops duplicate ix_answer_field). Check no 'running' rows in cip_load_log first.
3. `python -m etl.forsta_etl --discover` then `--due` (31 readable closed surveys, 24 of them tracker waves).
   Confirm the data call without `cond` returns all statuses (total_n ≈ 500, qualified ≈ 400).
4. `python scripts/reconcile.py` against the API.
5. Replace the two Excel-loaded Forsta waves (survey_id 1 = 2026-09-21, 2 = 2026-09-28, source_ref
   `selfserve/58f/260908`) with their API loads 260906 / 260907, delete the old rows only after those verify.
6. Finish SurveyMonkey reload: `python -m etl.legacy_dwh --all --era surveymonkey` (16 of 145 loaded).
7. Task 7 UI: search page over `cip_search` (FULLTEXT on MySQL, LIKE on SQLite); survey report auto-charting
   each question by shape — bar, donut, ranked bar, diverging stack, heatmap, bipolar butterfly
   (`cip_item.left_label/right_label`), numeric distribution, verbatims; Plotly transitions;
   `scripts/perf_check.py` P95 < 2 s; Playwright/browser check.
8. Task 8: opus review + fixes; update spec status, README, docs/03, docs/06; memory; final report listing
   changed files (no commit). Offer to delete `/private/tmp/claude-501/forsta/` (raw API downloads with
   respondent data, outside the repo).

## Investigation facts (don't re-derive)
- API v1: `GET rh/companies/all/surveys`, `surveys/{path}/datamap?format=json`, `surveys/{path}/data?format=json`.
  428 = hibernated; Forsta deletes after 365 days. OpenAPI spec: docs.developer.focusvision.com/static/media/decipher-api.yaml
- One weekly tracker wave = one survey `selfserve/58f/YYMMNN`; Monday launch 12–13 UTC; fielding median 12.8 h;
  ~400 qualified / ~500 total; sample source 114. Tags: "Weekly consumer tracker" (69), "annual tracker", ad hoc.
  56 hibernated (45 tracker). 260906 = wave 2026-09-21, 260907 = 2026-09-28.
- Datamap: questions[] with qlabel, qtitle, type (single/multiple/float/number/text), grouping, variables[]
  (label,rowTitle,colTitle,type,values), flags (t technical, v virtual). values may sit on question OR variables.
  "- NORMALIZED" copies = derived. Bipolar grids (HX6) have blank option titles; right statement from `{q}_norm{row}_r`.
  `oe` text variables inside single/multiple questions → own text questions.
  Core every wave: q1–q5, D1–D8, CS1–CS2 + system; modules rotate (BT, TF, HX, IN…). D2 = age bands 2025, single years 2026.
- Data: all strings; status "3" = qualified; date "09/28/2026 10:56". PII dropped: userAgent, url, session, dcua,
  ipAddress; RID kept only as sha256 `respondent_key`.
- API vs Excel-loaded 260907: 120,861/128,712 values equal; Excel lost ~3,300 HX6 bipolar answers; list/qtime/record
  were stored as code 1 (wrong).
- dwh_stg now: Forsta 2 waves (Excel), Qualtrics 142, SurveyMonkey 16/145, 1,050 match proposals pending,
  publication BEAUTY_RETAILERS_SHOPPERS_2024_25 v3 live.

## Known traps
- Azure MySQL ~250 ms RTT; read engine AUTOCOMMIT, no pre-ping; ONLY_FULL_GROUP_BY.
- PyMySQL executemany only batches when VALUES is all placeholders (no literals).
- Collation mix legacy utf8mb4_unicode_ci vs cip 0900_ai_ci → match in Python, not SQL joins.
- SQLite tests go through `sqlite_compat` (drops FULLTEXT, rewrites ON DUPLICATE KEY UPDATE) — avoid
  MySQL-only functions (LEFT, CONCAT, IF) in shared SQL.
- `tests/test_schema_v2.py` expects 31 `cip_` tables; plan() always has BACKFILL, so test only ALTER/CREATE/DROP.

## Session 2 notes (7 Oct 2026)
- Raw downloads in /private/tmp/claude-501/forsta deleted (disk was full: 130 MB free machine-wide).
- Loader now reuses a Forsta survey's wave by source_ref — delete Excel survey_id 1 and 2 (source_ref 260908!)
  BEFORE any new-code load of 260908, or it would reuse survey 1's wave label.
- Portal for checks runs on port 8611.
- 20:55 IST: `--due` backfill 22/30 loaded, 0 errors, still running (log: session scratchpad due.log; old code in memory).

## Next steps (in order, after `--due` finishes)
1. Check register: `SELECT load_state, COUNT(*) FROM cip_forsta_survey GROUP BY 1` — expect 31 loaded, 0 failed.
2. Delete harmoniser maps of virtual questions loaded by the old code:
   `DELETE m FROM cip_concept_map m JOIN cip_question q ON q.question_id = m.question_id WHERE q.is_virtual = 1`,
   then `python -m app.data.cube --all` is NOT needed (virtual cells unread); run `python -m etl.forsta_etl --reindex`.
3. `python scripts/reconcile.py` for Forsta waves (expect 0 differences; hibernated ones skipped).
4. Delete Excel survey_id 1 and 2 (source_ref 260908, waves 09-21/09-28) once 260906 / 260907 reconcile:
   child rows first (answers, respondents+profiles+cohorts, fields, items, options, questions, agg cells, concept maps, load log).
5. `python -m etl.legacy_dwh --all --era surveymonkey` (16 of 145), then `--reindex`.
6. README status table numbers; memory; final report; stop the portal on 8611.

## Session 3 (8 Oct 2026) — ETL hardening, team-file replication, schedule, diagrams
- Previous `--due` run died with the session at survey 262 (Holiday 2026, 260905) in `loading`; 4 waves still due:
  260902, 260905, 260906, 260908. DB writes from the assistant were refused by the auto-mode
  classifier — every dwh_stg change below waits for the user.
- `cip_tracker_line` + `etl/tracker_line.py` + `config/tracker_line.yml`: the team's "Weekly Line-By-Line"
  rows built per tracker wave after every load. `--compare` (reads only) vs the team's file: 16 waves equal
  except 3 file defects (July Month 07-26; Under-18 banded over 60/Boomer; cinema + live-performance columns
  missing in 10 waves). Documented in docs/03.
- Wave reuse on reload now keyed on the API load log (`forsta:{path}`), so Excel-era surveys 1/2
  (source_ref 260908) can never be overwritten by the 260908 load.
- Survey list fetched once per run (was once per wave).
- Schedule installed: launchd `com.coresight.cip-forsta-etl` (daily 09:00 IST; Tue+Wed 14:00, 23:30 IST),
  log `logs/forsta-etl.log`. The run exits 2 until `scripts/init_db.py` creates cip_tracker_line.
- Partitioning: decided by measurement — logical by wave; physical PARTITION deferred (FKs + FULLTEXT on
  cip_answer; 0.25 s P95). Spec §3.3 updated.
- Archify (all gates pass, screenshots inspected): .archify/architecture-forsta-etl-20261008/forsta-etl.html,
  .archify/architecture-cip-database-20261008/cip-database.html, .archify/lifecycle-forsta-wave-20261008/forsta-wave.html
- 219 tests pass.

## dwh_stg steps — done 8 Oct 2026 (user authorised: "you should be able to do everything")
- Connection was never the problem: portal account (STG_DB_USER) has ALL on dwh_stg; the Modular-Code DB_USER_DWH
  account has SELECT on dwh_stg and ALL on an empty `cip_stg` database. Earlier refusals were Claude Code's
  permission check, not MySQL.
1. init_db: cip_tracker_line created (32 cip_ tables).
2. `--due`: 260905 → 262 (2,261 resp; was stuck 'loading'), 260902 → 264, 260906 → 265, 260908 → 266 (wave 2026-10-05). 0 failed.
3. tracker_line --rebuild: 9,262 lines / 23 waves; --reindex: 191 waves (concept rows now built once per reindex).
4/5. Reconcile vs Forsta API: 31 waves, 4,476,153 answers, 0 differ. Excel surveys 1 and 2 deleted (their 22 reviewed
   mappings exist identically on 235); 12 orphan '- NORMALIZED' concepts deleted. Verified waves: Forsta 31,
   Qualtrics 142, SurveyMonkey 16 (+ reload running).
6. SurveyMonkey reload running detached (pid 82906 at start), log `logs/surveymonkey-reload-20261008.log`, ~4 h.
   If it stops: rerun `python -m etl.legacy_dwh --all --era surveymonkey` (idempotent), then `--reindex`.

## Session 3b (8 Oct 2026) — survey calendar + UI designs
- Survey calendar: 12-sector weekly rotation (each every 12 weeks), topics, holiday tracker numbered by season,
  annual + client studies. `cip_wave_module` created on dwh_stg (242 rows, all 90 surveys); rebuilt by discover + load.
  225 tests pass.
- The user's "Holiday Survey Databank" Excel (season 2026 wave 2, week of Oct 5) reproduces exactly from the cube
  (53.9 / 37.2 / 8.2 / 61.7 / Walmart 44.6 / gens 62-50-27-26). Its "vs LY" needs the 2025 holiday waves, 8 of 9 hibernated.
- UI design canvas (private): https://claude.ai/artifact/DCVCpQShGXUm8FLEAc5YLh — calendar, register, holiday databank.

## Check 13 Oct 2026 — scheduled runs
- launchd runs: Oct 9, 10, 12 09:00 OK (nothing due); Oct 11 09:04, Oct 13 09:00 and 14:00 failed: MySQL connect timed out
  (public IP changed 103.211.52.68 → .3; DB reachable again at 14:12). Manual catch-up run 14:13: OK, nothing due.
- This week's wave 261000 (Home improvement + Holiday Tracker, launched Oct 12) is still "live" in Forsta (404 / 595) —
  loads automatically once closed.
- SurveyMonkey reload finished Oct 8 19:15: 145/145 verified. Verified waves: Forsta 31, Qualtrics 142, SurveyMonkey 145.
- weekly_forsta now retries the database 4 × 5 min before giving up (exit 4). 227 tests pass.

## Documentation (13 Oct 2026)
- Combined: docs/CIP-Business-Description.{md,pdf,docx}, docs/CIP-Technical-Specification.{md,pdf,docx}
  (rebuild: `python scripts/build_docs.py`). Sources: docs/business/Business-Description.md, docs/technical/00–08
  (06 generated: `python scripts/data_dictionary.py > docs/technical/06-data-dictionary.md`).
- Diagrams: docs/diagrams/01–08 (.mmd, .excalidraw, .svg, .png) + Archify: ETL architecture, database design,
  survey lifecycle, scheduled-run sequence (.archify/…).
- dwh_stg: table comments added to cip_forsta_survey, cip_search, cip_tracker_line, cip_wave_module.

## ETL explainer PDF (13 Oct 2026)
- `docs/CIP-ETL-Pipeline-Explained.{html,pdf}`: colour-coded, 17 pages, inline keyword definitions, flow diagrams; worked example checked against DB (survey 266: 823 resp, 187,468 answers).
- Rebuild: Chrome headless `--print-to-pdf` on the HTML.

## Move to cip_stg (14 Oct 2026)
- All 33 `cip_` tables + 9 `v_cip_` views copied dwh_stg → cip_stg (same server) as `mohdsaeedafri`; DDL from SHOW CREATE (indexes, FKs, FULLTEXT, comments, AUTO_INCREMENT identical).
- Verified: every table definition equal, row counts equal, CHECKSUM TABLE equal on all 33 (cip_answer 23,114,175 rows); views equal.
- One fix during copy: DEFAULT CURRENT_TIMESTAMP columns were first skipped (MySQL tags them DEFAULT_GENERATED); restored from source by primary key, then re-checksummed equal.
- `dwh_sm*` history read through 6 pass-through views in cip_stg (`dwh_smsurveydetail`, `…question`, `…answer`, `…response`, `…responseqa`, `…demography` → dwh_stg), so legacy loader/reconcile are unchanged.
- `.env`: STG_DB_NAME=cip_stg, STG_DB_USER=mohdsaeedafri (password from Modular-Code/.env).
- Code/docs: grants file, schema header, setup.sh, footer, export source, data dictionary, README, technical/business docs, diagrams, ETL explainer PDF, combined docs rebuilt.
- Checks: test_connection ok; weekly_forsta.py exit 0 on cip_stg; portal on 8611 reads cip_stg; 227 tests pass.
- launchd job paused during the copy, reloaded after.
- Old cip_ tables in dwh_stg left in place as a fallback (dwh_app_access could drop them); drop only on the user's word.
- Full reconcile on cip_stg (14–15 Oct): 318 waves; all Forsta waves that are still readable match (incl. 261000: 147,635 answers); 3 loaded Forsta waves now hibernated (ecommerce, 260406, 260607) skipped by design; 1 pre-existing legacy gap: 2019-02-04 Apparel (SurveyMonkey 165769350) matrix question 212807096 "resale/rental/subscription" — 1,669 source rows whose answer ids are not in dwh_smanswer, so the loader never loaded it. Same in dwh_stg (tables checksum-identical); not caused by the move.
- 15 Oct: user ordered the CIP objects dropped from dwh_stg (manager: CIP tables only in cip_stg). `scripts/drop_cip_from_dwh_stg.py` drops exactly 33 cip_ tables + 9 v_cip_ views after checking cip_stg; report mode run OK (42 found, all safe). Not yet dropped: needs a dwh_stg account with DROP (dwh_app_access); mohdsaeedafri is SELECT-only there.
- Audit of dwh_stg (327 objects): only CIP objects came from this project. census_/bls_/bea_/fred_ (32 objects, created 15–16 Sep 2026) came from Claude sessions in ~/All-Code-Base/US-census-ETL; last written there 28–29 Sep. No VA tables. Nothing else traced to a Claude session.
- 15 Oct: user also wants census_/bls_/bea_/fred_ (32) dropped from dwh_stg (they live in coresight_market_data_stg). All 32 exist there, but 4 BLS series (12 obs) and 112 BEA series (7,051 obs) exist only in dwh_stg. Script `--macro` option added: drops them only when no series is missing; currently stops on BLS. Census and FRED pass.

## 15 Oct — CIP objects dropped from dwh_stg
- First `--yes` run stopped with "not in cip_stg yet": the dwh_app_access login has no rights on cip_stg, so information_schema hid it. Fixed `scripts/drop_cip_from_dwh_stg.py` to read the cip_stg side (objects, row counts) through the project login (`get_engine("etl")`).
- Dry run listed 42; `--yes` dropped all 42 (33 cip_ tables, 9 v_cip_ views). dwh_stg now 285 objects (was 327), 0 cip_/v_cip_ left; 32 census/bls/bea/fred and 7 dwh_sm* untouched.
- cip_stg intact: 42 objects, cip_answer 23,114,175 rows, dwh_smsurveydetail view reads 312 rows.
- weekly_forsta.py exit 0 (db=cip_stg, Loaded 0); 227 tests pass.
- Open: macro (census/bls/bea/fred) drop waits on the user's decision — 116 BLS/BEA series (7,063 obs) exist only in dwh_stg. Note: `--macro` also checks coresight_market_data_stg through the dwh_stg login, which likely can't see it — switch that check to the project login before using it.

## 15 Oct — macro (census/bls/bea/fred) objects in dwh_stg
- US-census-ETL launchd jobs run with MACRO_DB_PROFILE=DWH and Modular-Code/.env, where DB_NAME_DWH=coresight_market_data_stg; nothing reads dwh_stg. Code references 32 tables/views (other matched names are functions/variables); all 32 exist in market data. Last dwh_stg write 28–29 Sep; market data last runs 12–14 Oct.
- Backed up the dwh_stg-only rows to ~/All-Code-Base/US-census-ETL/backups/dwh_stg_only_2026-10-15/ (bls_series 4, bls_observation 12, bea_series 112, bea_observation 7,051, bea_table_line 265).
- Drop script ready: ~/All-Code-Base/US-census-ETL/backups/dwh_stg_only_2026-10-15/drop_from_dwh_stg.py (checks exactly 32 found, all present in market data; views first; reports market-data counts before/after). My run was denied by the auto-mode classifier; the user runs it.
- 09:00 CIP run 15 Oct: DB connect timeout (network), not related; manual run 10:13 OK.
- 15 Oct: user ran drop_from_dwh_stg.py — dropped 32; no census/bls/bea/fred left in dwh_stg; dwh_stg now 253 objects; market-data counts unchanged (census_series 14,599, bls_series 365,233, bea_series 10,674, fred_series 41, bea_table_line 15,452). dwh_stg cleanup complete: 74 objects removed (42 CIP + 32 macro).
