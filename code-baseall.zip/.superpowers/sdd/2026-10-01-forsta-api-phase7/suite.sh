#!/bin/bash
cd /Users/mohdsaeedafri/All-Code-Base/consumer-insight-portal
CSI_TEST_RAW=~/Downloads/"Raw Data 09_21_26.xlsx" CSI_TEST_XTAB=~/Downloads/"Cross Tabs 09_21_26.xlsx" .venv/bin/python -m pytest -q "$@"
