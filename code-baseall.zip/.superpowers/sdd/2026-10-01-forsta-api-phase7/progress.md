# SDD ledger — plan: docs/superpowers/plans/2026-10-01-forsta-api-phase7.md
Repo rule: never commit. BASE 762b01a.
Pre-flight: T1 questions_from_datamap + T2 to_record → T3 ingest_api parity → T4 verify/runner. Consistent.
Exit test (live weekly run) BLOCKED on the Forsta key (account disabled).
Task 1: complete (commits 762b01a..762b01a, tests: .superpowers/sdd/2026-10-01-forsta-api-phase7/suite.sh → 179 passed, 1226 warnings in 26.03s)
Task 2: complete (commits 762b01a..762b01a, tests: .superpowers/sdd/2026-10-01-forsta-api-phase7/suite.sh → 179 passed, 1226 warnings in 18.83s)
Task 3: complete (commits 762b01a..762b01a, tests: .superpowers/sdd/2026-10-01-forsta-api-phase7/suite.sh → 179 passed, 1226 warnings in 23.32s)
Task 5: live run 2026-10-01 00:35 IST → 401 key rejected → exit 2 (as designed). Exit test BLOCKED on the key.
Task 4: complete (commits 762b01a..762b01a, tests: .superpowers/sdd/2026-10-01-forsta-api-phase7/suite.sh → 182 passed, 1240 warnings in 19.36s)
Task 5: complete (commits 762b01a..762b01a, tests: .superpowers/sdd/2026-10-01-forsta-api-phase7/suite.sh → 182 passed, 1240 warnings in 18.83s)
Final: review of Phases 6+7 (fresh, opus) — 1 Critical, 6 Important, ~10 Minor. Probe: all 21 matrices are SurveyMonkey, none checkbox (per-response = rows) — I5's Qualtrics/checkbox risks are latent; guards added anyway.
Final: fixed C1 incremental API runs always failing verification — test_a_second_incremental_run_verifies_only_what_it_brought RED→GREEN (verify scoped to the payload's respondents; exposed a pre-existing _watermark strftime-on-str bug, fixed)
Final: fixed I1 failed API load left visible — test_a_failed_verification_leaves_the_wave_marked_failed_and_out_of_the_lists RED→GREEN (load_status loading→verified/failed; list_surveys and concept reads show verified only)
Final: fixed I2 variables named apart from their question dropped — test_variables_named_apart_from_their_question_still_load RED→GREEN (+ datamap variables without a field fail verification)
Final: fixed I3 panel mixing into answered groups — test_a_question_answer_keeps_its_whole_group_the_panel_does_not_mix_in RED→GREEN (groups merged in Python: MySQL evaluates ON DUPLICATE assignments left to right)
Final: fixed I4 panel profiles never refreshing — test_a_reload_picks_up_changed_panel_data RED→GREEN (profiles deleted and rebuilt per load)
Final: fixed I5 matrix fallback guessing — test_a_matrix_with_plain_answers_and_several_row_labels_is_skipped_not_guessed RED→GREEN (single only with exactly one blank row; checkbox matrices skipped and flagged)
Final: fixed I6 unanswered matrix rows becoming scale points — test_a_matrix_row_nobody_answered_is_not_a_scale_point RED→GREEN
Final: fixed (re-graded Minor→Important: false reconcile failures across 145 waves) matrix text variants — test_matrix_text_variants_of_one_cell_reconcile_as_one RED→GREEN
Final: fixed (re-graded Minor→Important: whole wave shows 0 qualified) float status/codes — test_float_codes_and_status_are_read_as_numbers RED→GREEN
Final: fixed (re-graded Minor→Important: one bad wave stopped 145) --all per-wave isolation — test_one_bad_wave_does_not_stop_the_rest RED→GREEN
Final: fixed watermark '>' skipping a same-minute record — covered by the incremental test
Final: minor (deferred): weekly_forsta: network/5xx in whoami and drift exceptions exit 1 (not a distinct code)
Final: minor (deferred): an unparseable record date passes the watermark filter unverified by date
Final: minor (deferred): income_mid_k misses en-dash / "to" ranges; malformed "$,-$," crashes int()
Final: minor (deferred): _matrix query filters question_id without survey_id (index use)
Final: minor (deferred): duplicate demography rows with conflicting values are merged column-wise by MIN
Final: minor (deferred): a load exception before finish_run in the Excel path leaves its run 'running' (API path fixed)
